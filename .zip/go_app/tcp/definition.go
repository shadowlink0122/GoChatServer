package main

const(
	DISCONNECT = iota
	SEED

	ELSE
)
